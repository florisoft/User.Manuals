Standaard fustfoto's voor Florisoft Returnables

Pak de map uit en stel Apps > PackagingPicturesFolderPath in op de uitgepakte map.
De bestandsnaam van iedere foto is de bijbehorende fustcode, gevolgd door .jpg.
